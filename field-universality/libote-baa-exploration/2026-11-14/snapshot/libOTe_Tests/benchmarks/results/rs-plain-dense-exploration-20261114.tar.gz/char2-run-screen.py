from pathlib import Path
import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp,xlogy
import json
from math import comb,log

def propose(a,b,d,start=None):
 deg=np.array([0]+list(range(9,17))); dims=np.array([0]+list(range(1,9))); coeff=np.log([1]+[comb(16,i) for i in range(9,17)])
 def unpack(p):
  z,tau=np.exp(p[:2]);st=[]
  for base in (2,5):
   x,y,l=np.exp(p[base:base+3]);lam=1+l
   w=x*y/(lam-y);A=x*y/(lam-1);B=x/(lam-y)
   st.append((x,y,lam,w,A,B))
  return z,tau,st
 def obj(p):
  z,tau,st=unpack(p)
  v=logsumexp(coeff+deg*p[0]+dims*p[1])/16-a*p[0]
  for x,y,l,w,A,B in st:v+=log(l)
  v-=a*p[2]+b*(p[3]+p[5])+d*p[6]
  return (v+sum(xlogy(t,t) for t in (a,1-a,b,1-b)))/log(2)
 def cons(p):
  z,tau,st=unpack(p);r=[]
  for x,y,l,w,A,B in st:
   r.extend([1-w-1/tau,1-A*B])
  return np.array(r)
 if start is None:start=np.array([-1.,1.,-1.,-1.,-.5,-1.,-1.,-.5])
 res=minimize(obj,start,method='SLSQP',bounds=[(-30,10),(0,20)]+[(-25,10),(-25,0),(-25,10)]*2,
 constraints=[dict(type='ineq',fun=cons)], options=dict(maxiter=1200,ftol=1e-11))
 return dict(a=a,b=b,delta=d,exponent_per_n=float(res.fun),success=bool(res.success),min_constraint=float(min(cons(res.x))),values=res.x.tolist())
if __name__=='__main__':
 records=[]
 for d in (.066,.1):
  for a,b in ((.001,.002),(.05,.04),(.1,.08),(.2,.12),(.3,.16),(.4,.2)):
   p=propose(a,b,d);records.append(p);print(d,a,b,p['exponent_per_n'],p['success'],flush=True)
 Path('out/baa-opt/char2-run-screen.json').write_text(json.dumps(records,indent=2))
