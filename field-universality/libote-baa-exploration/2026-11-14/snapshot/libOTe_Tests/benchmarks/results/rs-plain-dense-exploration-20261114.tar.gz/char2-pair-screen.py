from pathlib import Path
import sys,json, numpy as np
from math import comb,log
from scipy.special import xlogy,logsumexp
from scipy.optimize import minimize
sys.path.insert(0,'C:/Users/peter/repo/gen-BAA/field-universality/expander-lift')
from convolution_design_space import propose
H=lambda v: -xlogy(v,v)-xlogy(1-v,1-v)
roots,weights=np.polynomial.legendre.leggauss(96);nodes=(roots+1)/2;weights/=2

def shape_entropy(a,b,c,m2):
 rest=c-m2;extra=a-3*c+m2
 if min(rest,extra,c-a+b,a/2-c,m2,1-b-c)<-1e-8:return None
 rest=max(0,rest);extra=max(0,extra)
 return (1-b)*H(c/(1-b))+b*H((a-c)/b)+xlogy(c,c)-xlogy(m2,m2)-xlogy(rest,rest)+xlogy(rest+extra,rest+extra)-xlogy(rest,rest)-xlogy(extra,extra)

def source(a,b,delta):
 p=propose(1,1,8,delta,a,b);z,tau=p['values'][:2]
 w=np.array([0]+list(range(9,17)));d=np.array([0]+list(range(1,9)))
 logs=np.array([0]+[log(comb(16,int(v))) for v in w[1:]])+w*z+d*tau
 mass=np.exp(logs-logsumexp(logs))/16
 # Nonconstant polynomials have nonzero fibers of size <=7; weight9 exact.
 E=np.array([0,15,58,65,74,85,98,99,256])
 A=float(mass@w);D=float(mass@d);U=float(mass[1:]@(E[1:]/w[1:]))
 entropy=logsumexp(logs)/16-A*z-D*tau
 return dict(a=A,b=b,delta=delta,D=D,U=U,entropy=entropy,masses=mass.tolist(),values=p['values'])

def inner(S,c,m2,start=None):
 a,b,D,U,delta=[S[k] for k in ('a','b','D','U','delta')];sh=shape_entropy(a,b,c,m2)
 if sh is None:return None
 j=m2*nodes;rho=np.minimum(1,a*U/(a-2*j)**2)
 def obj(v):
  t=np.exp(-v[0]);gain=m2*float(weights@np.log(t+(1-t)*rho))
  return (S['entropy']+sh-H(a)-H(b)+D*v[0]+gain+v[4]-b*v[1]-delta*v[2])/log(2)
 def cons(v):
  t,x,y,vec,lam=np.exp(v)
  return [lam-1-x*y*vec,lam-y-x*y-x/(t*vec),lam-y-x/vec]
 fit=minimize(obj,start if start is not None else [2,-1,-2,0,.1],method='SLSQP',bounds=[(0,20),(-20,10),(-20,0),(-20,20),(0,10)],constraints=[dict(type='ineq',fun=cons)],options=dict(maxiter=400,ftol=1e-10))
 return dict(c=c,m2=m2,exponent=float(fit.fun),success=bool(fit.success),values=fit.x.tolist(),min_constraint=float(min(cons(fit.x))))

if __name__=='__main__':
 rows=[]
 for a,b in ((.05,.04),(.1,.08),(.2,.12),(.3,.16)):
  S=source(a,b,.1);a=S['a'];best=None
  for f in (.001,.25,.5,.75,.999):
   c=(a-b)*(1-f)+a/2*f
   for g in (.001,.25,.5,.75,.999):
    low=max(0,3*c-a);m2=low+(c-low)*g
    r=inner(S,c,m2)
    if r and (best is None or r['exponent']>best['exponent']):best=r
  rows.append(dict(source=S,worst_sample=best));print(a,b,S['D'],S['U'],best,flush=True)
 Path('out/baa-opt/char2-pair-screen.json').write_text(json.dumps(rows,indent=2))
