from pathlib import Path
import csv, fcntl, json, statistics, subprocess

root=Path(__file__).resolve().parent
locks=[]
for name in ('prindal-addition-encoder-benchmark','bare-spin-benchmark','hypercat-benchmark'):
 f=open('/tmp/'+name+'.lock','w');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(f)
result=root/'results';result.mkdir(exist_ok=True)
rows=[]
for seed in range(1,7):
 text=subprocess.check_output(['taskset','-c','2',str(root/'directions-wide4'),
  '2097152','31',str(seed)],text=True)
 (result/f'q2-{seed}.csv').write_text(text)
 records=list(csv.DictReader(text.splitlines()));rows+=records
 assert records[1]['checksum']==records[2]['checksum']
 print(seed,[(r['code'],r['forward_ms'],r['transpose_ms']) for r in records],flush=True)
summary={}
for code in sorted({r['code'] for r in rows}):
 summary[code]={}
 for direction in ('forward_ms','transpose_ms'):
  values=[float(r[direction]) for r in rows if r['code']==code]
  summary[code][direction]={'median':statistics.median(values),'min':min(values),'max':max(values)}
(result/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
