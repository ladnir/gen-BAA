from pathlib import Path
import csv, fcntl, hashlib, json, subprocess, sys

root=Path(__file__).resolve().parent
base=root.parent
mode=sys.argv[1]
flags={'wide4':['-march=native'], 'avx2':['-maes','-mpclmul','-msse4.1','-mavx2']}[mode]
result=root/'results';result.mkdir(exist_ok=True)
if sys.argv[2]=='build':
 sources=[root/'libOTe_Tests/benchmarks/ChosenBaaTranspose.cpp']+[base/'cryptoTools/cryptoTools'/f for f in
  ('Crypto/AES.cpp','Crypto/PRNG.cpp','Common/block.cpp','Common/Log.cpp')]
 cmd=['c++','-O3','-DNDEBUG','-std=c++20',*flags,'-I'+str(base/'build'/mode),
  '-I'+str(root),'-I'+str(base),'-I'+str(base/'cryptoTools'),*map(str,sources),
  '-pthread','-o',str(root/('transpose-'+mode))]
 subprocess.run(cmd,check=True)
 manifest={'command':cmd,'compiler':subprocess.check_output(['c++','--version'],text=True),
  'sources':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
   for p in sorted(root.rglob('*')) if p.suffix in ('.h','.cpp','.py')}}
 (result/(mode+'-build.json')).write_text(json.dumps(manifest,indent=2))
 sys.exit(0)
locks=[]
for name in ('prindal-addition-encoder-benchmark','bare-spin-benchmark','hypercat-benchmark'):
 f=open('/tmp/'+name+'.lock','w');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(f)
n=int(sys.argv[2]);iterations=int(sys.argv[3]);seeds=int(sys.argv[4])
def state():
 return {str(p):p.read_text().strip() for p in [Path('/proc/loadavg'),
  Path('/sys/devices/system/cpu/cpufreq/boost'),
  Path('/sys/devices/system/cpu/cpu2/cpufreq/scaling_cur_freq')] if p.exists()}
for seed in range(1,seeds+1):
 before=state()
 output=subprocess.check_output(['taskset','-c','2',str(root/('transpose-'+mode)),
  str(n),str(iterations),str(seed)],text=True)
 prefix=f'{mode}-{n}-{seed}'
 (result/(prefix+'.csv')).write_text(output)
 (result/(prefix+'-host.json')).write_text(json.dumps({'before':before,'after':state()},indent=2))
 rows=list(csv.DictReader(output.splitlines()))
 assert next(r for r in rows if r['code']=='rs_plain')['checksum']==next(r for r in rows if r['code']=='rs_plain_fused')['checksum']
 print(output,flush=True)
