from pathlib import Path
import csv, fcntl, json, subprocess, sys

root=Path(__file__).resolve().parent
base=root.parent
mode=sys.argv[1]
flags={'wide4':['-march=native'],
       'avx2':['-maes','-mpclmul','-msse4.1','-mavx2'],
       'wide2':['-maes','-mpclmul','-msse4.1','-mavx2','-mvpclmulqdq'],
       'portable':[]}[mode]
if sys.argv[2]=='build':
 for kind,source in [('directions','ChosenBaaDirections.cpp'),('stages','ChosenBaaStages.cpp')]:
  sources=[root/'libOTe_Tests/benchmarks'/source]+[base/'cryptoTools/cryptoTools'/f for f in
   ('Crypto/AES.cpp','Crypto/PRNG.cpp','Common/block.cpp','Common/Log.cpp')]
  subprocess.run(['c++','-O3','-DNDEBUG','-std=c++20',*flags,'-I'+str(base/'build'/mode),
   '-I'+str(root),'-I'+str(base),'-I'+str(base/'cryptoTools'),*map(str,sources),
   '-pthread','-o',str(root/(kind+'-'+mode))],check=True)
 sys.exit(0)
locks=[]
for name in ('prindal-addition-encoder-benchmark','bare-spin-benchmark','hypercat-benchmark'):
 f=open('/tmp/'+name+'.lock','w');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(f)
result=root/'results';result.mkdir(exist_ok=True)
kind=sys.argv[2];n=int(sys.argv[3]);iterations=int(sys.argv[4]);seed=int(sys.argv[5])
prefix=f'{mode}-{kind}-{n}-{seed}'
def state():
 return {str(p):p.read_text().strip() for p in [Path('/proc/loadavg'),
  Path('/sys/devices/system/cpu/cpufreq/boost'),
  Path('/sys/devices/system/cpu/cpu2/cpufreq/scaling_cur_freq')] if p.exists()}
before=state()
text=subprocess.check_output(['taskset','-c','2',str(root/(('stages' if kind=='sweep' else kind)+'-'+mode)),
 str(n),str(iterations),str(seed),*(['sweep'] if kind=='sweep' else [])],text=True)
(result/(prefix+'.csv')).write_text(text)
(result/(prefix+'-host.json')).write_text(json.dumps({'before':before,'after':state()},indent=2))
rows=list(csv.DictReader(text.splitlines()))
if kind=='directions':
 pairs=[('gf128_nonbinary_q2_candidate','gf128_nonbinary_q2_shift_fused'),
        ('gf128_nonbinary_q2_generic_scan','gf128_nonbinary_q2_general_fused'),
        ('gf128_chosen_baa30','gf128_q256_fused')]
 for a,b in pairs:
  assert next(r for r in rows if r['code']==a)['checksum']==next(r for r in rows if r['code']==b)['checksum']
print(text,flush=True)
