from pathlib import Path
import csv, hashlib, json, statistics, tarfile

root=Path(__file__).resolve().parent
result=root/'results'
summary={'directions':{},'stages':{},'sweep':{}}
for kind in summary:
 groups={}
 for path in sorted(result.glob('*-'+kind+'-2097152-*.csv')):
  mode=path.name.split('-'+kind+'-')[0]
  for row in csv.DictReader(path.open()):
   if kind=='directions':
    for field in ('setup_ms','forward_ms','transpose_ms'):
     groups.setdefault((mode,row['code'],field),[]).append(float(row[field]))
   else:
    groups.setdefault((mode,row['code'],row['direction'],row['phase']),[]).append(float(row['median_ms']))
 for key,values in groups.items():
  obj=summary[kind]
  for part in key[:-1]:obj=obj.setdefault(part,{})
  obj[key[-1]]={'median':statistics.median(values),'min':min(values),'max':max(values),'seeds':len(values)}
(result/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
paths=[root/'fused-run.py',root/'summarize-fused.py',root/'directions-wide4',root/'stages-wide4',
 root/'directions-avx2',root/'stages-avx2']
paths+=list((root/'libOTe').rglob('*.h'))+list((root/'libOTe_Tests').rglob('*.cpp'))
(result/'sha256.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(root))+'\n' for p in paths))
with tarfile.open(root.parent/'peach-fused-stages-20261114.tar.gz','w:gz') as archive:
 for path in ('results','fused-run.py','summarize-fused.py','libOTe','libOTe_Tests'):
  archive.add(root/path,arcname=path)
print(json.dumps(summary['directions'],indent=2),flush=True)
